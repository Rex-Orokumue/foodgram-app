import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/api/api_client.dart';
import '../../../shared/models/story.model.dart';
import '../../../core/storage/secure_storage.dart';

class StoryViewerState {
  final List<StoryModel> stories;
  final bool isLoading;
  final String? error;

  const StoryViewerState({
    this.stories = const [],
    this.isLoading = false,
    this.error,
  });

  StoryViewerState copyWith({
    List<StoryModel>? stories,
    bool? isLoading,
    String? error,
  }) {
    return StoryViewerState(
      stories: stories ?? this.stories,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class StoryViewerNotifier extends Notifier<StoryViewerState> {
  @override
  StoryViewerState build() {
    return const StoryViewerState();
  }

  Future<void> loadStories(String userId) async {
    state = state.copyWith(isLoading: true, error: null);

    try {
      final dio = ApiClient.instance;
      final currentUserId = await SecureStorage.getUserId();

      List<StoryModel> userStories = [];

      if (userId == currentUserId) {
        final response = await dio.get('/stories/me');
        final storiesJson =
            response.data['data']['stories'] as List<dynamic>;
        
        final username = await SecureStorage.getUsername() ?? '';
        
        // Inject username into each story
        userStories = storiesJson.map((s) {
          final storyMap = Map<String, dynamic>.from(s as Map<String, dynamic>);
          storyMap['username'] = username;
          storyMap['display_name'] = username;
          storyMap['viewed_by_me'] = false;
          return StoryModel.fromJson(storyMap);
        }).toList();
      } else {
        // Loading someone else's stories — use feed endpoint
        final response = await dio.get('/stories/feed');
        final groupsJson =
            response.data['data']['stories'] as List<dynamic>;

        for (final group in groupsJson) {
          final groupData = group as Map<String, dynamic>;
          if (groupData['user_id'] == userId) {
            final storiesJson = groupData['stories'] as List<dynamic>;
            userStories = storiesJson
                .map((s) => StoryModel.fromJson(s as Map<String, dynamic>))
                .toList();
            break;
          }
        }
      }

      // Sort chronologically — oldest story first (WhatsApp-style playback)
      userStories.sort((a, b) => a.createdAt.compareTo(b.createdAt));

      state = state.copyWith(
        stories: userStories,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to load stories',
      );
    }
  }

  Future<void> viewStory(String storyId) async {
    try {
      final dio = ApiClient.instance;
      await dio.post('/stories/$storyId/view');
    } catch (e) {
      // View recording failed silently
    }
  }
}

final storyViewerProvider =
    NotifierProvider<StoryViewerNotifier, StoryViewerState>(() {
  return StoryViewerNotifier();
});